{{
    config(
        tags=['staging']
    )
}}
with columns as (
    select
     SUBSTRING(empid, 3) AS Employeeid,
     name,
     gender,
     department,
     experience,
    SUBSTRING(trainerid, 4) as Trainerid,
     trainername,
     trainingname,
     progress,
     start_date,
     end_date
 from {{ source('training', 'employee') }}
),
type_conversions as(
    select
    cast(Employeeid as int) as Employee_id,
    name,
    department,
    experience,
    cast(trainerid as int) as Trainer_id,
    trainername,
    trainingname,
    progress as performance,
    start_date,
    end_date
from columns
)

select * from type_conversions