{{
    config(
        tags=['mart']
    )
}}
with
intern as (
    select * from  {{ ref('stg_intern') }}
),
days AS (
    SELECT 
        DISTINCT trainingname,
        trainername,
        round(AVG(progress)) AS AverageProgress,
        round(AVG(scores)) AS AverageScores,
        DATEDIFF(day, startdate, enddate) AS No_of_Days 
    FROM 
        intern
    GROUP BY 
        trainingname,
        trainername,
        enddate,
        startdate
)
select * from days