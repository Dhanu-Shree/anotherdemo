
{{
    config(
        tags=['mart']
    )
}}
with
intern as (
    select * from  {{ ref('stg_intern') }}
),
RankedRows AS (
    SELECT 
        *,
        ROW_NUMBER() OVER (PARTITION BY name ORDER BY scores desc,progress desc) AS row_num
    FROM 
        intern
),

userresult as (
 SELECT name,trainingname,progress,scores
FROM RankedRows
WHERE row_num =1)

select * from userresult