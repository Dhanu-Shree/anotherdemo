
{{
    config(
        tags=['mart']
    )
}}
with
employee as (
    select * from  {{ ref('stg_employee') }}
),
RankedRows AS (
    SELECT 
        *,
        ROW_NUMBER() OVER (PARTITION BY trainingname ORDER BY performance desc) AS row_num
    FROM 
        employee
),
performance as (
    select name,trainingname,performance
    from RankedRows
    where row_num=1
)
select * from performance