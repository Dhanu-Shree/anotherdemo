{{
    config(
        tags=['mart']
    )
}}
with
intern as (
    select * from  {{ ref('stg_intern') }}
),

goodtrainers as (
    select trainerid, trainingname, avg(progress) as Overall_Progress,avg(scores) as Overall_Scores
    from intern 
    group by trainingname,trainerid

),
highratedtrainers as (
    select a.trainerid,b.trainername,a.trainingname,a.Overall_Progress,a.Overall_Scores
    from goodtrainers a join intern b
    where a.trainerid=b.trainerid
),
RankedRows AS (
    SELECT 
        *,
        ROW_NUMBER() OVER (PARTITION BY trainingname ORDER BY Overall_Scores desc, Overall_Progress desc) AS row_num
    FROM 
        highratedtrainers
),

toprank as(
      select trainerid,trainername, round(Overall_Scores) as Overall_Score,round(Overall_Progress)as Overall_Progress
    from RankedRows
    where row_num=1
    order by Overall_Score desc,Overall_Progress desc
)


select * from toprank