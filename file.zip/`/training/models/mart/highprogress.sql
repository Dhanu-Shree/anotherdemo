
{{
    config(
        tags=['mart']
    )
}}
with
intern as (
    select * from  {{ ref('stg_intern') }}
),
RankedRows AS (
    SELECT 
        *,
        ROW_NUMBER() OVER (PARTITION BY trainingname ORDER BY scores desc,progress desc) AS row_num
    FROM 
        intern
),
progress as (
    select name,trainingname,scores,progress
    from RankedRows
    where row_num=1
)

select * from progress


