<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
    crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <link rel="stylesheet" href="todostyle.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" 
    crossorigin="anonymous"></script>
    <title>TODOLIST</title>
</head>
<body>
    <div class="app">
        <h4 style="padding-left: 25%" class ="mb-3" >TODO App <i class="fa-solid fa-clipboard"></i></h4>
        <hr>
        <div style="margin: 30px;" class="search-container">
          <input style="background-color: #bcb3f0" class="text" id="searchInput" placeholder="Search...">
          <button style="background-color: #bcb3f0;" onclick="search()">Search</button>
      </div>
        <div id="addNew" data-bs-toggle="modal" data-bs-target="#form">
          <span style="margin: 5%;">Add yours</span>
          <i class="fas fa-plus"></i>
          <hr>
        </div>
          <h5 class="text-center my-3"></h5>
        <div id="tasks"></div>
       <!-- Modal -->
<form method='post'
class="modal fade"
id="form"
tabindex="-1"
aria-labelledby="exampleModalLabel"
aria-hidden="true"
>
<div class="modal-dialog">
  <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="exampleModalLabel">Your Tasks</h5>
      <button
        type="button"
        class="btn-close"
        data-bs-dismiss="modal"
        aria-label="Close"
      ></button>
    </div>
    <div class="modal-body">
      <p>To Do</p>
      <input type="text" class="form-control" name="title" id="textInput" />
      <div id="msg"></div>
      <br />
      <p>Date</p>
      <input type="date" class="form-control" name="date" id="dateInput" />
      <br />
     <!-- <p>Description</p>
      <textarea
        name=""
        class="form-control"
        id="textarea"
        cols="10"
        rows="2"
      ></textarea> -->
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
        Close
      </button>
      <button type="submit" id="add" class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
    </div>
    <script src="todoscript.js"></script>

</body>
</html><?php /**PATH C:\Users\DhanuShreeSS\Desktop\laravel\example-app\resources\views/index.blade.php ENDPATH**/ ?>