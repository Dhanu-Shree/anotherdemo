<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post" action="form.php">  
  Name: <input type="text" name="name">
  <br><br>
  E-mail: <input type="text" name="email">
  <input type="submit" name="submit" value="Submit"> 
</form>


</body>
</html><?php /**PATH C:\Users\DhanuShreeSS\Desktop\laravel\example-app\resources\views/form.blade.php ENDPATH**/ ?>