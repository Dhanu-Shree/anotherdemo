<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
</head>
<body>
   <form action="update/<?php echo e($users->id); ?>" method='POST'>
       <label for="name">Name</label>
       <input type="text" name="name" value="<?php echo e($users->name); ?>"><br>
       <label for="phone">Phone</label>
       <input type="text" name="phone" value="<?php echo e($users->phone); ?>"><br>
       <label for="age">Age</label>
       <input type="text" name="age" value="<?php echo e($users->age); ?>"><br>

       <input type="submit" value="Update Form">

       <?php echo csrf_field(); ?>
   </form> 
</body>
</html>
<?php /**PATH C:\Users\DhanuShreeSS\Desktop\laravel\example-app\resources\views/edit.blade.php ENDPATH**/ ?>