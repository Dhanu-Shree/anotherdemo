<div class="container center-container">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            @if(session('status'))
            <div class="alert alert-success">{{ session('status') }}</div>
            @endif
            <div class="card">
                <div class="card-header">
                    <h4>Categories
                        <a href="{{ url('categories/create') }}" class="btn btn-primary float-end">Back</a>
                    </h4>
                </div>
                <div class="card-body">
                    <form action="{{ url('categories/create') }}" method="POST">
                        @csrf
                        <div class="mb-3">
                            <label for="name" class="form-label"><h3>Name</h3></label>
                            <input type="text" class="form-control" id="name" name="name" value="{{ old('name') }}">
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label"><h3>Description</h3></label>
                            <input type="text" class="form-control" id="description" name="description" value="{{ old('description') }}">
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" {{ old('is_active') ? 'checked' : '' }}>
                                <label class="form-check-label" for="is_active">
                                    <h3>Is active</h3>
                                </label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    html, body, .container, .row, .col-md-6 {
        height: 100%;
    }

    .center-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh; /* Set the height to the viewport height to center vertically */
    }

    .mb-3 {
        margin-bottom: 15px; /* Add margin between each field */
    }

    .card {
        border: 1px solid #ccc; /* Add border to the card */
        border-radius: 8px;
        width: 100%;
        max-width: 600px; /* Limit the card width */
    }

    .card-header {
        background-color: #f0f0f0; /* Add background color to the card header */
        border-bottom: 1px solid #ccc; /* Add border to the card header */
        padding: 10px 15px; /* Add padding to the card header */
    }

    .card-body {
        padding: 20px;
    }

    .form-label h3 {
        font-size: 20px; /* Adjust the font size of form labels */
    }

    .form-check-label h3 {
        font-size: 18px; /* Adjust the font size of form checkbox labels */
    }

    input[type="text"] {
        font-size: 18px; /* Adjust the font size of input fields */
    }
</style>
