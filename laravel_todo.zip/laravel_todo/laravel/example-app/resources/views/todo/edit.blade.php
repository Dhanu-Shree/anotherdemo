<div class="container center-container">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    <h2 style="text-align:center">Categories
                    </h2>
                </div>
                <div class="card-body">
                <form action="{{ url('update/'.$categories->id)}}" method="POST">
                        @csrf
                        <h3>
                        <div class="mb-3">
                            <label for="name" class="form-label">Task:</label>
                           <h3>
                             <input type="text" class="form-control" id="name" name="name" value="{{ $categories->name }}">
                    </div>
</h3>

<h3>
                        <div class="mb-3">
                       
                            <label for="description" class="form-label">Description</label>
                            <br><br>
                            <input type="textarea" class="form-control" id="description" name="description" value="{{ $categories->description}}">
                        </div>
</h3>
<h3>
                        <div class="mb-3">
                            <div class="form-check">
                                
                                <label class="form-check-label" for="is_active">
                                    Is active
                                </label>
                                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="{{ $categories->is_active }}">
                            </div>

                        </div>
                        </h3>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    .center-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh; /* Set the height to the viewport height to center vertically */
    }

    .mb-3 {
        margin-bottom: 15px; /* Add margin between each field */
    }

    .card {
        border: 2px solid #ccc;
        border-radius: 15px;
        width: 120%; /* Adjust width based on content */
        margin: auto;
        margin-top: 20px;
        min-height: 80vh; /* Add border radius to the card */
    }

    .card-header {
        background-color: lightblue; /* Add background color to the card header */
        border-bottom: 1px solid #ccc; /* Add border to the card header */
        padding: 10px 15px; /* Add padding to the card header */
    }

    .card-body {
        padding: 20px;
        height: auto; /* Allow card body to expand as needed */
    }

    .form-label {
        font-size: 20px; /* Increase font size of labels */
    }

    .form-control {
        font-size: 20px; /* Increase font size of inputs */
    }

    .form-check-label {
        font-size: 20px; /* Increase font size of checkbox labels */
    }

    .form-check-input {
        width: 30px; /* Adjust width of checkbox */
        height: 30px; /* Adjust height of checkbox */
    }
    .btn-primary {
        font-size: 20px; /* Increase font size of button */
        padding: 10px 30px;
        background-color:lightblue;
        justify-content: center;
        align-items: center;
        text-align:center;
    }
</style>
