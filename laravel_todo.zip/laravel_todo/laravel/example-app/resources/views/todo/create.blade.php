<div class="container center-container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                   <h2>
                    <a href="{{ url('categories') }}" class="btn btn-primary float-end">Add category</a></h2>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped text-center">
                        <thead>
                            <tr>
                             
                                <th><h2>Tasks</h2></th>
                                <th><h2>Description</h2></th>
                                <th><h2>Status</h2></th>
                                <th><h2>Edit</h2></th>
                                <th><h2>Delete</h2></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($categories as $item)
                            <tr>
                               
                                <td><h4>{{ $item->name }}</h4></td>
                                <td><h4>{{ $item->description }}</h4></td>
                                <td>
                                    <h4>
                                    @if($item->is_active)
                                        Not Completed
                                    @else
                                        Completed
                                    @endif
</h4>
                                </td>
                                <td>
                                    <h4>
                                    <a href="/edit/{{$item->id}}">Edit</a>
                                    </h4>
                                </td>
                                <td>
                                    <h4>
                                    <a href="/delete/{{$item->id}}" >Delete</a>
                                     </h4>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .card {
        border: 2px solid #ccc;
        border-radius: 15px;
        width: 90%; /* Adjust width based on content */
        margin: auto;
        margin-top: 20px;
        min-height: 80vh; /* Ensure card occupies a larger portion of the screen */
    }

    .card-header {
        background-color: #3490dc;
        border-bottom: 2px solid #ccc;
        border-radius: 15px 15px 0 0;
        padding: 10px 15px;
    }

    .card-header h4 {
        color: white;
        margin-bottom: 0;
    }

    .card-body {
        padding: 20px;
        height: 70%; /* Ensure card body occupies entire height */
    }

    .table {
        border: 2px solid #dee2e6;
        border-radius: 15px;
        width:100%;
        height:100%; /* Ensure table fills entire height of card body */
    }

    .table th,
    .table td {
        border: 1px solid #dee2e6;
    }


    .table-striped tbody tr:nth-of-type(odd) {
        background-color: #f8f9fa;
    }

    .btn {
        margin-right: 5px;
    }

    .center-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%; /* Adjust height to center content vertically */
    }
</style>