<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Crud;

class CrudController extends Controller
{
    public function create(){
        return view('createuser');
    }
    public function store(Request $request){

        $data=$request->only(['name','phone','age']);
       $user= Crud::create($data);
    //  $name=$request->input('name');
    //  $phone=$request->input('phone');
    //  $age=$request->input('age');

    //  $user=new Crud;
    //  $user->name=$name;
    //  $user->phone=$phone;
    //  $user->age=$age;

    //  $user->save();
   return "form created successfully";

    }

    public function list(){
        $user=Crud::all();
        return view('list',['users'=>$user]);

    }

    public function edit($id){
        $user=Crud::find($id);

        return view('edit',['users'=>$user]);
    }

    public function update(Request $request,$id){
        $user=Crud::find($id);
        $user->$name=$request->input('name');
    $user-> $phone=$request->input('phone');
     $user->$age=$request->input('age');
     $user->save();
     return "User updated sucssessfully <a href='/'>Click</a>";
    }
}
